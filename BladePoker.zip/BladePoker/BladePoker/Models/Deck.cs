﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BladePoker.Models
{
    public class Deck
    {
        public List<Card> cards { get; set; }
    }
}
