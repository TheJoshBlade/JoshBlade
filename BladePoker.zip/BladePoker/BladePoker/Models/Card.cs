﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BladePoker.Models
{
    public class Card
    {
        public string suit { get; set; }
        public string value { get; set; }
    }
}
